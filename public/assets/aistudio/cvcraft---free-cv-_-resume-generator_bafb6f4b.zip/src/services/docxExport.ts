import {
  Document,
  Packer,
  Paragraph,
  TextRun,
  HeadingLevel,
  AlignmentType,
  BorderStyle,
  Table,
  TableRow,
  TableCell,
  WidthType,
} from 'docx';
import { CV } from '../types/cv.ts';

export async function exportCvToDocx(cv: CV): Promise<void> {
  const { data, title, themeColor = '#2563eb', customHeadings = {}, sectionVisibility = {} } = cv;
  const {
    personalInfo,
    summary,
    experience,
    education,
    skills,
    projects,
    certifications,
    languages,
    customSections,
  } = data;

  // Convert hex color to 6-digit hex without #
  const hexColor = (themeColor.startsWith('#') ? themeColor.slice(1) : themeColor).padEnd(6, '0').slice(0, 6);

  const children: (Paragraph | Table)[] = [];

  // Helper for Section Heading
  const createSectionHeading = (defaultTitle: string, key: string) => {
    const headingText = (customHeadings[key] || defaultTitle).toUpperCase();
    return new Paragraph({
      heading: HeadingLevel.HEADING_2,
      spacing: { before: 240, after: 120 },
      border: {
        bottom: {
          color: hexColor,
          space: 2,
          style: BorderStyle.SINGLE,
          size: 12,
        },
      },
      children: [
        new TextRun({
          text: headingText,
          bold: true,
          color: hexColor,
          size: 22, // 11pt
          font: 'Arial',
        }),
      ],
    });
  };

  // 1. CANDIDATE HEADER
  if (sectionVisibility.personalInfo !== false) {
    // Name
    children.push(
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 0, after: 60 },
        children: [
          new TextRun({
            text: personalInfo.fullName || 'Candidate Name',
            bold: true,
            size: 36, // 18pt
            font: 'Arial',
            color: '111827',
          }),
        ],
      })
    );

    // Job Title
    if (personalInfo.jobTitle) {
      children.push(
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 0, after: 80 },
          children: [
            new TextRun({
              text: personalInfo.jobTitle,
              bold: true,
              size: 24, // 12pt
              font: 'Arial',
              color: hexColor,
            }),
          ],
        })
      );
    }

    // Contact Details Line
    const contactParts: string[] = [];
    if (personalInfo.location) contactParts.push(personalInfo.location);
    if (personalInfo.phone) contactParts.push(personalInfo.phone);
    if (personalInfo.email) contactParts.push(personalInfo.email);
    if (personalInfo.website) contactParts.push(personalInfo.website.replace(/^https?:\/\//, ''));
    if (personalInfo.linkedin) contactParts.push(personalInfo.linkedin.replace(/^https?:\/\//, ''));
    if (personalInfo.github) contactParts.push(personalInfo.github.replace(/^https?:\/\//, ''));

    if (contactParts.length > 0) {
      children.push(
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 0, after: 180 },
          children: [
            new TextRun({
              text: contactParts.join('  |  '),
              size: 19, // 9.5pt
              font: 'Arial',
              color: '4B5563',
            }),
          ],
        })
      );
    }

    // Additional Demographic fields (if provided by user)
    const extraDetails: string[] = [];
    if (personalInfo.dateOfBirth) extraDetails.push(`Date of Birth: ${personalInfo.dateOfBirth}`);
    if (personalInfo.nationality) extraDetails.push(`Nationality: ${personalInfo.nationality}`);
    if (personalInfo.maritalStatus) extraDetails.push(`Marital Status: ${personalInfo.maritalStatus}`);
    if (personalInfo.visaStatus) extraDetails.push(`Visa / Work Rights: ${personalInfo.visaStatus}`);
    if (personalInfo.religion) extraDetails.push(`Religion: ${personalInfo.religion}`);
    if (personalInfo.bloodGroup) extraDetails.push(`Blood Group: ${personalInfo.bloodGroup}`);
    if (personalInfo.fatherName) extraDetails.push(`Father's Name: ${personalInfo.fatherName}`);
    if (personalInfo.motherName) extraDetails.push(`Mother's Name: ${personalInfo.motherName}`);
    if (personalInfo.permanentAddress) extraDetails.push(`Permanent Address: ${personalInfo.permanentAddress}`);

    if (extraDetails.length > 0) {
      children.push(
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 0, after: 180 },
          children: [
            new TextRun({
              text: extraDetails.join('  ·  '),
              size: 18,
              font: 'Arial',
              color: '6B7280',
              italics: true,
            }),
          ],
        })
      );
    }
  }

  // 2. PROFESSIONAL SUMMARY
  if (sectionVisibility.summary !== false && summary) {
    children.push(createSectionHeading('Professional Summary', 'summary'));
    children.push(
      new Paragraph({
        spacing: { before: 60, after: 120 },
        children: [
          new TextRun({
            text: summary,
            size: 20, // 10pt
            font: 'Arial',
            color: '1F2937',
          }),
        ],
      })
    );
  }

  // 3. WORK EXPERIENCE
  if (sectionVisibility.experience !== false && experience && experience.length > 0) {
    children.push(createSectionHeading('Work Experience', 'experience'));
    experience.forEach((exp) => {
      // Role & Date
      children.push(
        new Paragraph({
          spacing: { before: 120, after: 40 },
          children: [
            new TextRun({
              text: exp.role,
              bold: true,
              size: 21,
              font: 'Arial',
              color: '111827',
            }),
            new TextRun({
              text: `   (${exp.startDate} – ${exp.current ? 'Present' : exp.endDate})`,
              size: 19,
              font: 'Arial',
              color: '4B5563',
              italics: true,
            }),
          ],
        })
      );

      // Company & Location
      children.push(
        new Paragraph({
          spacing: { before: 0, after: 60 },
          children: [
            new TextRun({
              text: `${exp.company}${exp.location ? ` · ${exp.location}` : ''}`,
              bold: true,
              size: 19,
              font: 'Arial',
              color: hexColor,
            }),
          ],
        })
      );

      // Overview description
      if (exp.description) {
        children.push(
          new Paragraph({
            spacing: { before: 0, after: 60 },
            children: [
              new TextRun({
                text: exp.description,
                size: 20,
                font: 'Arial',
                color: '374151',
              }),
            ],
          })
        );
      }

      // Achievement Highlights (bullets)
      if (exp.highlights && exp.highlights.length > 0) {
        exp.highlights.forEach((bullet) => {
          if (!bullet.trim()) return;
          children.push(
            new Paragraph({
              bullet: { level: 0 },
              spacing: { before: 20, after: 40 },
              children: [
                new TextRun({
                  text: bullet,
                  size: 20,
                  font: 'Arial',
                  color: '374151',
                }),
              ],
            })
          );
        });
      }
    });
  }

  // 4. EDUCATION
  if (sectionVisibility.education !== false && education && education.length > 0) {
    children.push(createSectionHeading('Education & Credentials', 'education'));
    education.forEach((edu) => {
      children.push(
        new Paragraph({
          spacing: { before: 80, after: 30 },
          children: [
            new TextRun({
              text: `${edu.degree}${edu.field ? ` in ${edu.field}` : ''}`,
              bold: true,
              size: 21,
              font: 'Arial',
              color: '111827',
            }),
            new TextRun({
              text: `   (${edu.startDate} – ${edu.endDate})`,
              size: 19,
              font: 'Arial',
              color: '4B5563',
              italics: true,
            }),
          ],
        })
      );

      children.push(
        new Paragraph({
          spacing: { before: 0, after: 60 },
          children: [
            new TextRun({
              text: `${edu.institution}${edu.location ? ` · ${edu.location}` : ''}${edu.gpa ? ` (GPA: ${edu.gpa})` : ''}`,
              size: 19,
              font: 'Arial',
              color: '374151',
            }),
          ],
        })
      );

      if (edu.description) {
        children.push(
          new Paragraph({
            spacing: { before: 0, after: 60 },
            children: [
              new TextRun({
                text: edu.description,
                size: 19,
                font: 'Arial',
                color: '6B7280',
                italics: true,
              }),
            ],
          })
        );
      }
    });
  }

  // 5. SKILLS
  if (sectionVisibility.skills !== false && skills && skills.length > 0) {
    children.push(createSectionHeading('Skills & Competencies', 'skills'));
    skills.forEach((cat) => {
      children.push(
        new Paragraph({
          spacing: { before: 40, after: 40 },
          children: [
            new TextRun({
              text: `${cat.category}: `,
              bold: true,
              size: 20,
              font: 'Arial',
              color: '111827',
            }),
            new TextRun({
              text: cat.items.join(', '),
              size: 20,
              font: 'Arial',
              color: '374151',
            }),
          ],
        })
      );
    });
  }

  // 6. PROJECTS
  if (sectionVisibility.projects !== false && projects && projects.length > 0) {
    children.push(createSectionHeading('Key Projects', 'projects'));
    projects.forEach((proj) => {
      children.push(
        new Paragraph({
          spacing: { before: 80, after: 30 },
          children: [
            new TextRun({
              text: proj.name,
              bold: true,
              size: 20,
              font: 'Arial',
              color: '111827',
            }),
            proj.link
              ? new TextRun({
                  text: ` (${proj.link})`,
                  size: 18,
                  font: 'Arial',
                  color: hexColor,
                })
              : new TextRun({ text: '' }),
          ],
        })
      );

      if (proj.technologies && proj.technologies.length > 0) {
        children.push(
          new Paragraph({
            spacing: { before: 0, after: 30 },
            children: [
              new TextRun({
                text: `Technologies: ${proj.technologies.join(', ')}`,
                size: 18,
                font: 'Arial',
                color: '6B7280',
                italics: true,
              }),
            ],
          })
        );
      }

      children.push(
        new Paragraph({
          spacing: { before: 0, after: 60 },
          children: [
            new TextRun({
              text: proj.description,
              size: 19,
              font: 'Arial',
              color: '374151',
            }),
          ],
        })
      );
    });
  }

  // 7. CERTIFICATIONS & LANGUAGES
  if (
    (sectionVisibility.certifications !== false && certifications && certifications.length > 0) ||
    (sectionVisibility.languages !== false && languages && languages.length > 0)
  ) {
    children.push(createSectionHeading('Certifications & Languages', 'certifications'));

    if (certifications && certifications.length > 0) {
      certifications.forEach((c) => {
        children.push(
          new Paragraph({
            bullet: { level: 0 },
            spacing: { before: 20, after: 20 },
            children: [
              new TextRun({
                text: `${c.name} `,
                bold: true,
                size: 19,
                font: 'Arial',
              }),
              new TextRun({
                text: `— ${c.issuer} (${c.issueDate}${c.credentialId ? `, ID: ${c.credentialId}` : ''})`,
                size: 19,
                font: 'Arial',
                color: '4B5563',
              }),
            ],
          })
        );
      });
    }

    if (languages && languages.length > 0) {
      children.push(
        new Paragraph({
          spacing: { before: 60, after: 20 },
          children: [
            new TextRun({
              text: 'Languages: ',
              bold: true,
              size: 19,
              font: 'Arial',
            }),
            new TextRun({
              text: languages.map((l) => `${l.language} (${l.proficiency})`).join(', '),
              size: 19,
              font: 'Arial',
              color: '374151',
            }),
          ],
        })
      );
    }
  }

  // 8. CUSTOM SECTIONS
  if (sectionVisibility.customSections !== false && customSections && customSections.length > 0) {
    customSections.forEach((cSec) => {
      children.push(createSectionHeading(cSec.title || 'Additional Information', cSec.id));
      children.push(
        new Paragraph({
          spacing: { before: 40, after: 80 },
          children: [
            new TextRun({
              text: cSec.content,
              size: 20,
              font: 'Arial',
              color: '374151',
            }),
          ],
        })
      );
    });
  }

  // Construct Word Document
  const doc = new Document({
    creator: 'CVCraft Professional Resume Generator',
    title: title || `${personalInfo.fullName || 'Candidate'} CV`,
    description: `Generated by CVCraft for ${personalInfo.fullName}`,
    sections: [
      {
        properties: {
          page: {
            margin: {
              top: 1000,
              right: 1000,
              bottom: 1000,
              left: 1000,
            },
          },
        },
        children,
      },
    ],
  });

  // Generate blob and trigger browser download
  const blob = await Packer.toBlob(doc);
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  const sanitizedFilename = (title || `${personalInfo.fullName || 'Candidate'}_CV`)
    .replace(/[^a-zA-Z0-9_-]/g, '_')
    .toLowerCase();
  a.download = `${sanitizedFilename}.docx`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
