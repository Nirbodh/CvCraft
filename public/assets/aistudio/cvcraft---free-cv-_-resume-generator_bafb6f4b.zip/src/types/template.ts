export type TemplateCategory =
  | 'ats'
  | 'modern'
  | 'classic'
  | 'minimal'
  | 'executive'
  | 'creative'
  | 'technical'
  | 'academic'
  | 'traditional'
  | 'custom';

export interface TemplateMetadata {
  id: string;
  name: string;
  countryId: string;
  category: TemplateCategory;
  description: string;
  defaultLanguage: string;
  version: string;
  isCustomHtml: boolean;
  htmlContent?: string;
  cssContent?: string;
  enabled: boolean;
  isSystem?: boolean;
  thumbnailColor?: string;
  tags?: string[];
  createdAt: string;
  updatedAt: string;
}

export interface CountryItem {
  id: string;
  name: string;
  flag: string;
  documentTerm: string;
  defaultLanguage: string;
  recommendedLength?: string;
  photoConvention?: 'discouraged' | 'optional' | 'common' | 'standard';
  photoExplanation?: string;
  atsGuidance?: string;
  enabled: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface TranslationFieldItem {
  key: string;
  label: string;
  category: string;
  originalText: string;
  translatedText: string;
}

export interface TranslationResult {
  sourceLanguage: string;
  targetLanguage: string;
  fields: TranslationFieldItem[];
  translatedAt: string;
  provider: string;
}
