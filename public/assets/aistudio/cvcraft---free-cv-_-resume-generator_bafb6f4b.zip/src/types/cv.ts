export type TemplateId =
  | 'ats'
  | 'modern'
  | 'classic'
  | 'minimal'
  | 'executive'
  | 'creative'
  | 'technical'
  | 'academic'
  | 'professional' // alias for modern executive
  | 'japanese-rirekisho'
  | 'japanese-shokumu'
  | string; // Allow custom user-created templates

export type CountryId =
  | 'usa'
  | 'canada'
  | 'uk'
  | 'germany'
  | 'eu'
  | 'australia'
  | 'uae'
  | 'bangladesh'
  | 'japan'
  | string; // Allow custom user-added countries

export type FontFamily = 'sans' | 'serif' | 'mono';
export type SpacingScale = 'compact' | 'normal' | 'relaxed';
export type FontSizeScale = 'compact' | 'normal' | 'large';
export type MarginScale = 'compact' | 'normal' | 'relaxed';

export interface PersonalInfo {
  fullName: string;
  jobTitle: string;
  email: string;
  phone: string;
  location: string;
  website?: string;
  linkedin?: string;
  github?: string;
  // Country & Profile Photo configuration
  photo?: string; // base64 or image URL
  showPhoto?: boolean;
  photoShape?: 'circle' | 'rounded' | 'square';
  // Optional country profile fields
  dateOfBirth?: string;
  nationality?: string;
  maritalStatus?: string;
  visaStatus?: string;
  religion?: string;
  bloodGroup?: string;
  fatherName?: string;
  motherName?: string;
  permanentAddress?: string;
  // Japanese Rirekisho (履歴書) specific fields
  furiganaName?: string; // ふりがな (氏名)
  furiganaAddress?: string; // ふりがな (現住所)
  gender?: string; // 男 / 女 / 未記載
  commuteTime?: string; // 通勤時間 (e.g., 約1時間15分)
  dependentsCount?: string; // 扶養家族数 (配偶者を除く)
  spouse?: string; // 配偶者 (有・無)
  spouseSupport?: string; // 配偶者の扶養義務 (有・無)
  selfPr?: string; // 自己PR / 志望動機 / 特技
  reasonForApplying?: string; // 志望動機
  personalPreferences?: string; // 本人希望記入欄 (給与・職種・勤務時間等)
}

export interface ExperienceItem {
  id: string;
  role: string;
  company: string;
  location?: string;
  startDate: string;
  endDate: string;
  current: boolean;
  description: string;
  highlights?: string[];
}

export interface EducationItem {
  id: string;
  degree: string;
  field: string;
  institution: string;
  location?: string;
  startDate: string;
  endDate: string;
  gpa?: string;
  description?: string;
}

export interface SkillCategory {
  id: string;
  category: string;
  items: string[];
}

export interface ProjectItem {
  id: string;
  name: string;
  description: string;
  link?: string;
  technologies: string[];
  highlights?: string[];
}

export interface CertificationItem {
  id: string;
  name: string;
  issuer: string;
  issueDate: string;
  expiryDate?: string;
  credentialId?: string;
  url?: string;
}

export interface LanguageItem {
  id: string;
  language: string;
  proficiency: string; // e.g., Native, Fluent, Professional, Conversational, or CEFR (C2, C1, B2)
}

export interface CustomSectionItem {
  id: string;
  title: string;
  content: string;
}

export interface CvData {
  personalInfo: PersonalInfo;
  summary: string;
  experience: ExperienceItem[];
  education: EducationItem[];
  skills: SkillCategory[];
  projects: ProjectItem[];
  certifications: CertificationItem[];
  languages: LanguageItem[];
  customSections: CustomSectionItem[];
}

export interface CV {
  _id?: string;
  id?: string;
  userId?: string;
  title: string;
  countryId: CountryId;
  templateId: TemplateId;
  themeColor: string;
  fontFamily: FontFamily;
  spacing: SpacingScale;
  fontSize: FontSizeScale;
  margins: MarginScale;
  customHeadings: Record<string, string>;
  sectionOrder: string[];
  sectionVisibility: Record<string, boolean>;
  data: CvData;
  // Multi-language translation support
  activeLanguage?: string;
  translations?: Record<string, CvData>;
  originalData?: CvData;
  // Custom HTML/CSS Template Support
  isCustomTemplate?: boolean;
  customTemplateHtml?: string;
  customTemplateCss?: string;
  createdAt?: string;
  updatedAt?: string;
}

export const COLOR_PALETTES = [
  { name: 'Executive Navy', value: '#1e3a8a', label: 'Navy' },
  { name: 'Modern Sapphire', value: '#2563eb', label: 'Blue' },
  { name: 'Emerald Forest', value: '#059669', label: 'Emerald' },
  { name: 'Burgundy Slate', value: '#831843', label: 'Wine' },
  { name: 'Anthracite Dark', value: '#18181b', label: 'Monochrome' },
  { name: 'Warm Amber', value: '#b45309', label: 'Amber' },
  { name: 'Cyan Tech', value: '#0891b2', label: 'Teal' },
  { name: 'Nordic Slate', value: '#475569', label: 'Slate' },
];

export const INITIAL_CV_DATA: CvData = {
  personalInfo: {
    fullName: 'Alex Vance',
    jobTitle: 'Senior Full-Stack Engineer',
    email: 'alex.vance@example.com',
    phone: '+1 (555) 234-5678',
    location: 'San Francisco, CA',
    website: 'https://alexvance.dev',
    linkedin: 'linkedin.com/in/alexvance',
    github: 'github.com/alexvance',
    showPhoto: false,
    photoShape: 'circle',
    nationality: 'American',
    dateOfBirth: '',
    maritalStatus: '',
    visaStatus: '',
  },
  summary:
    'Dedicated Full-Stack Engineer with 6+ years of expertise in architecting resilient distributed systems, modern React applications, and high-throughput microservices. Proven success leading cross-functional teams to modernize legacy pipelines, decreasing latency by 42% and accelerating release velocity.',
  experience: [
    {
      id: 'exp_1',
      role: 'Staff Systems Architect',
      company: 'Apex Cloud Solutions',
      location: 'San Francisco, CA',
      startDate: '2022',
      endDate: 'Present',
      current: true,
      description:
        'Spearheaded the redesign of core multi-tenant transaction infrastructure serving 1.2M+ daily active requests.',
      highlights: [
        'Architected real-time event streaming pipeline processing 45k events/sec with sub-20ms p99 latency.',
        'Mentored 8 mid-level engineers in distributed design patterns, automated testing, and CI/CD best practices.',
        'Reduced cloud computing overhead by $180,000 annually through containerized autoscaling optimizations.',
      ],
    },
    {
      id: 'exp_2',
      role: 'Senior Software Engineer',
      company: 'Nexus Software Labs',
      location: 'Austin, TX',
      startDate: '2019',
      endDate: '2022',
      current: false,
      description:
        'Developed mission-critical web applications utilizing React, Node.js, and PostgreSQL for enterprise fintech clients.',
      highlights: [
        'Streamlined client onboarding workflow, cutting document verification time by 60%.',
        'Implemented rigorous test automation suite achieving 92% code coverage across vital payment microservices.',
      ],
    },
  ],
  education: [
    {
      id: 'edu_1',
      degree: 'Bachelor of Science',
      field: 'Computer Science',
      institution: 'University of Washington',
      location: 'Seattle, WA',
      startDate: '2015',
      endDate: '2019',
      gpa: '3.85 / 4.0',
      description: 'Magna Cum Laude. Specialization in Distributed Computing and Algorithms.',
    },
  ],
  skills: [
    {
      id: 'sk_1',
      category: 'Languages & Frameworks',
      items: ['TypeScript', 'JavaScript', 'React', 'Node.js', 'Express', 'Python', 'Go', 'Tailwind CSS'],
    },
    {
      id: 'sk_2',
      category: 'Cloud & Infrastructure',
      items: ['Docker', 'Kubernetes', 'AWS', 'MongoDB', 'PostgreSQL', 'Redis', 'CI/CD Pipelines'],
    },
  ],
  projects: [
    {
      id: 'proj_1',
      name: 'OmniStream Analytics Engine',
      description:
        'High-performance distributed telemetry dashboard providing real-time anomalies detection and alerting.',
      link: 'https://github.com/alexvance/omnistream',
      technologies: ['TypeScript', 'React', 'Node.js', 'Tailwind CSS'],
      highlights: [
        'Processed over 10M records per day with zero data loss.',
        'Adopted by 4 open-source enterprise communities.',
      ],
    },
  ],
  certifications: [
    {
      id: 'cert_1',
      name: 'AWS Certified Solutions Architect – Professional',
      issuer: 'Amazon Web Services',
      issueDate: '2023',
      expiryDate: '2026',
      credentialId: 'AWS-PSA-99412',
    },
  ],
  languages: [
    { id: 'lang_1', language: 'English', proficiency: 'Native / Bilingual' },
    { id: 'lang_2', language: 'Spanish', proficiency: 'Professional Working' },
  ],
  customSections: [
    {
      id: 'cust_1',
      title: 'Publications & Speaking',
      content:
        'Keynote speaker at CloudDev Summit 2024: "Architecting Zero-Downtime Microservices at Scale". Co-author of IEEE whitepaper on resilient state management.',
    },
  ],
};

export const DEFAULT_SECTION_ORDER = [
  'personalInfo',
  'summary',
  'experience',
  'education',
  'skills',
  'projects',
  'certifications',
  'languages',
  'customSections',
];

export const DEFAULT_SECTION_VISIBILITY: Record<string, boolean> = {
  personalInfo: true,
  summary: true,
  experience: true,
  education: true,
  skills: true,
  projects: true,
  certifications: true,
  languages: true,
  customSections: true,
};

export const DEFAULT_CV: CV = {
  title: 'Senior Software Engineer CV',
  countryId: 'usa',
  templateId: 'modern',
  themeColor: '#2563eb',
  fontFamily: 'sans',
  spacing: 'normal',
  fontSize: 'normal',
  margins: 'normal',
  customHeadings: {},
  sectionOrder: DEFAULT_SECTION_ORDER,
  sectionVisibility: DEFAULT_SECTION_VISIBILITY,
  data: INITIAL_CV_DATA,
};
