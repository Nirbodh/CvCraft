import React from 'react';
import { CustomSectionItem } from '../../types/cv.ts';
import { Plus, Trash2 } from 'lucide-react';

interface CustomSectionsProps {
  items: CustomSectionItem[];
  onChange: (updated: CustomSectionItem[]) => void;
}

export const CustomSections: React.FC<CustomSectionsProps> = ({ items, onChange }) => {
  const addItem = () => {
    const newItem: CustomSectionItem = {
      id: 'cust_' + Math.random().toString(36).substring(2, 9),
      title: 'Additional Section',
      content: '',
    };
    onChange([...items, newItem]);
  };

  const updateItem = (id: string, updates: Partial<CustomSectionItem>) => {
    onChange(items.map((it) => (it.id === id ? { ...it, ...updates } : it)));
  };

  const removeItem = (id: string) => {
    onChange(items.filter((it) => it.id !== id));
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <span className="text-xs font-semibold text-slate-700">Custom Sections</span>
        <button
          type="button"
          onClick={addItem}
          className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-white bg-blue-600 hover:bg-blue-700 rounded transition-colors cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Custom Section</span>
        </button>
      </div>

      {items.length === 0 ? (
        <div className="text-center py-6 px-4 bg-slate-50 border border-dashed border-slate-200 rounded text-xs text-slate-500">
          No custom sections added yet. Click &ldquo;Add Custom Section&rdquo; for Publications, Volunteering, or Awards.
        </div>
      ) : (
        <div className="space-y-3">
          {items.map((item) => (
            <div key={item.id} className="p-3 border border-slate-200 rounded-md bg-white space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <input
                  type="text"
                  value={item.title}
                  onChange={(e) => updateItem(item.id, { title: e.target.value })}
                  placeholder="Section Title (e.g. Publications, Volunteer Work)"
                  className="font-semibold text-slate-900 border-b border-transparent hover:border-slate-300 focus:border-blue-600 focus:outline-none px-1 py-0.5 w-2/3"
                />
                <button
                  type="button"
                  onClick={() => removeItem(item.id)}
                  className="p-1 text-slate-400 hover:text-rose-600 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>

              <div>
                <textarea
                  rows={3}
                  value={item.content}
                  onChange={(e) => updateItem(item.id, { content: e.target.value })}
                  placeholder="Enter details, description, or bullet items for this section..."
                  className="w-full px-2.5 py-1.5 border border-slate-200 rounded text-slate-900 leading-relaxed"
                />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
