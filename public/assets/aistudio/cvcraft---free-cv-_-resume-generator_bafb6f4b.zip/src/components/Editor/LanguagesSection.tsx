import React from 'react';
import { LanguageItem } from '../../types/cv.ts';
import { Plus, Trash2 } from 'lucide-react';

interface LanguagesSectionProps {
  items: LanguageItem[];
  onChange: (updated: LanguageItem[]) => void;
}

const PROFICIENCY_LEVELS = [
  'Native / Bilingual',
  'Full Professional',
  'Professional Working',
  'Conversational',
  'Elementary',
];

export const LanguagesSection: React.FC<LanguagesSectionProps> = ({ items, onChange }) => {
  const addItem = () => {
    const newItem: LanguageItem = {
      id: 'lang_' + Math.random().toString(36).substring(2, 9),
      language: '',
      proficiency: 'Professional Working',
    };
    onChange([...items, newItem]);
  };

  const updateItem = (id: string, updates: Partial<LanguageItem>) => {
    onChange(items.map((it) => (it.id === id ? { ...it, ...updates } : it)));
  };

  const removeItem = (id: string) => {
    onChange(items.filter((it) => it.id !== id));
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <span className="text-xs font-semibold text-slate-700">Languages</span>
        <button
          type="button"
          onClick={addItem}
          className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-white bg-blue-600 hover:bg-blue-700 rounded transition-colors cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add Language</span>
        </button>
      </div>

      {items.length === 0 ? (
        <div className="text-center py-6 px-4 bg-slate-50 border border-dashed border-slate-200 rounded text-xs text-slate-500">
          No languages added.
        </div>
      ) : (
        <div className="space-y-2">
          {items.map((item) => (
            <div key={item.id} className="p-2.5 border border-slate-200 rounded-md bg-white flex items-center gap-3 text-xs">
              <input
                type="text"
                value={item.language}
                onChange={(e) => updateItem(item.id, { language: e.target.value })}
                placeholder="Language (e.g. French)"
                className="flex-1 px-2.5 py-1 border border-slate-200 rounded text-slate-900"
              />
              <select
                value={item.proficiency}
                onChange={(e) => updateItem(item.id, { proficiency: e.target.value })}
                className="px-2.5 py-1 border border-slate-200 rounded text-slate-900 bg-white"
              >
                {PROFICIENCY_LEVELS.map((lvl) => (
                  <option key={lvl} value={lvl}>
                    {lvl}
                  </option>
                ))}
              </select>
              <button
                type="button"
                onClick={() => removeItem(item.id)}
                className="p-1 text-slate-400 hover:text-rose-600 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
