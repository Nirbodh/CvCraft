import React, { useState } from 'react';
import { PersonalInfo } from '../../types/cv.ts';
import {
  User,
  Briefcase,
  Mail,
  Phone,
  MapPin,
  Globe,
  Linkedin,
  Github,
  Camera,
  Trash2,
  ChevronDown,
  ChevronUp,
  Info,
} from 'lucide-react';

interface PersonalSectionProps {
  data: PersonalInfo;
  onChange: (updated: PersonalInfo) => void;
}

export const PersonalSection: React.FC<PersonalSectionProps> = ({ data, onChange }) => {
  const [showDemographics, setShowDemographics] = useState(
    Boolean(
      data.dateOfBirth ||
        data.nationality ||
        data.maritalStatus ||
        data.visaStatus ||
        data.fatherName ||
        data.permanentAddress
    )
  );

  const handleChange = (field: keyof PersonalInfo, value: any) => {
    onChange({
      ...data,
      [field]: value,
    });
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (file.size > 2 * 1024 * 1024) {
        alert('Photo must be under 2MB.');
        return;
      }
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          onChange({
            ...data,
            photo: event.target.result as string,
            showPhoto: true,
          });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemovePhoto = () => {
    onChange({
      ...data,
      photo: undefined,
      showPhoto: false,
    });
  };

  return (
    <div className="space-y-5">
      {/* 1. Optional Profile Photo Row */}
      <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          {data.photo ? (
            <div className="relative">
              <img
                src={data.photo}
                alt="Profile Preview"
                className={`w-14 h-14 object-cover border-2 border-slate-300 ${
                  data.photoShape === 'circle'
                    ? 'rounded-full'
                    : data.photoShape === 'square'
                    ? 'rounded-none'
                    : 'rounded-lg'
                }`}
              />
            </div>
          ) : (
            <div className="w-14 h-14 rounded-lg bg-slate-200 text-slate-400 flex items-center justify-center">
              <Camera className="w-6 h-6" />
            </div>
          )}

          <div>
            <span className="font-bold text-xs text-slate-900 block">Professional Headshot</span>
            <span className="text-[11px] text-slate-500 block">
              Common in Germany, UAE, and Bangladesh · Discouraged in US, UK, and Canada
            </span>
            <div className="flex items-center gap-2 mt-1">
              <label className="text-[11px] text-blue-600 font-semibold hover:underline cursor-pointer">
                {data.photo ? 'Change photo' : 'Upload photo'}
                <input
                  type="file"
                  accept="image/png, image/jpeg, image/webp"
                  className="hidden"
                  onChange={handlePhotoUpload}
                />
              </label>
              {data.photo && (
                <>
                  <span className="text-slate-300">·</span>
                  <button
                    type="button"
                    onClick={handleRemovePhoto}
                    className="text-[11px] text-rose-600 hover:underline cursor-pointer"
                  >
                    Remove
                  </button>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Shape and Toggle Controls */}
        {data.photo && (
          <div className="flex items-center gap-3 self-end sm:self-auto text-xs">
            <label className="inline-flex items-center gap-1.5 cursor-pointer text-[11px] font-medium text-slate-700">
              <input
                type="checkbox"
                checked={data.showPhoto !== false}
                onChange={(e) => handleChange('showPhoto', e.target.checked)}
                className="rounded text-blue-600"
              />
              <span>Show in CV</span>
            </label>

            <select
              value={data.photoShape || 'circle'}
              onChange={(e) => handleChange('photoShape', e.target.value)}
              className="px-2 py-1 bg-white border border-slate-200 rounded text-[11px] text-slate-800"
            >
              <option value="circle">Circle</option>
              <option value="rounded">Rounded</option>
              <option value="square">Square</option>
            </select>
          </div>
        )}
      </div>

      {/* 2. Primary Contact Details Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
            <User className="w-3.5 h-3.5 text-slate-400" />
            <span>Full Name <span className="text-rose-500">*</span></span>
          </label>
          <input
            type="text"
            value={data.fullName || ''}
            onChange={(e) => handleChange('fullName', e.target.value)}
            placeholder="e.g. Alex Vance"
            className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600 focus:border-blue-600 text-slate-900 placeholder:text-slate-400"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
            <Briefcase className="w-3.5 h-3.5 text-slate-400" />
            <span>Job Title <span className="text-rose-500">*</span></span>
          </label>
          <input
            type="text"
            value={data.jobTitle || ''}
            onChange={(e) => handleChange('jobTitle', e.target.value)}
            placeholder="e.g. Senior Software Engineer"
            className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600 focus:border-blue-600 text-slate-900 placeholder:text-slate-400"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
            <Mail className="w-3.5 h-3.5 text-slate-400" />
            <span>Email Address <span className="text-rose-500">*</span></span>
          </label>
          <input
            type="email"
            value={data.email || ''}
            onChange={(e) => handleChange('email', e.target.value)}
            placeholder="e.g. alex@example.com"
            className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600 focus:border-blue-600 text-slate-900 placeholder:text-slate-400"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
            <Phone className="w-3.5 h-3.5 text-slate-400" />
            <span>Phone Number</span>
          </label>
          <input
            type="tel"
            value={data.phone || ''}
            onChange={(e) => handleChange('phone', e.target.value)}
            placeholder="e.g. +1 (555) 019-2834"
            className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600 focus:border-blue-600 text-slate-900 placeholder:text-slate-400"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5 text-slate-400" />
            <span>Location / City, Country</span>
          </label>
          <input
            type="text"
            value={data.location || ''}
            onChange={(e) => handleChange('location', e.target.value)}
            placeholder="e.g. San Francisco, CA (or London, UK)"
            className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600 focus:border-blue-600 text-slate-900 placeholder:text-slate-400"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
            <Globe className="w-3.5 h-3.5 text-slate-400" />
            <span>Portfolio / Website</span>
          </label>
          <input
            type="url"
            value={data.website || ''}
            onChange={(e) => handleChange('website', e.target.value)}
            placeholder="e.g. https://alexvance.dev"
            className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600 focus:border-blue-600 text-slate-900 placeholder:text-slate-400"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
            <Linkedin className="w-3.5 h-3.5 text-slate-400" />
            <span>LinkedIn Profile</span>
          </label>
          <input
            type="text"
            value={data.linkedin || ''}
            onChange={(e) => handleChange('linkedin', e.target.value)}
            placeholder="e.g. linkedin.com/in/alexvance"
            className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600 focus:border-blue-600 text-slate-900 placeholder:text-slate-400"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1.5">
            <Github className="w-3.5 h-3.5 text-slate-400" />
            <span>GitHub Profile</span>
          </label>
          <input
            type="text"
            value={data.github || ''}
            onChange={(e) => handleChange('github', e.target.value)}
            placeholder="e.g. github.com/alexvance"
            className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-600 focus:border-blue-600 text-slate-900 placeholder:text-slate-400"
          />
        </div>
      </div>

      {/* 3. Collapsible Country & Demographic Information */}
      <div className="border border-slate-200 rounded-lg overflow-hidden bg-white">
        <button
          type="button"
          onClick={() => setShowDemographics(!showDemographics)}
          className="w-full p-3 bg-slate-50 hover:bg-slate-100 transition-colors flex items-center justify-between text-left cursor-pointer"
        >
          <div className="flex items-center gap-2">
            <Info className="w-4 h-4 text-slate-500" />
            <div>
              <span className="text-xs font-bold text-slate-900 block">
                Country-Specific &amp; Demographic Details (Optional)
              </span>
              <span className="text-[11px] text-slate-500 block">
                Nationality, Date of Birth, Visa Status, Biodata fields
              </span>
            </div>
          </div>
          {showDemographics ? (
            <ChevronUp className="w-4 h-4 text-slate-400" />
          ) : (
            <ChevronDown className="w-4 h-4 text-slate-400" />
          )}
        </button>

        {showDemographics && (
          <div className="p-3.5 bg-white border-t border-slate-100 space-y-3 text-xs">
            <p className="text-[11px] text-slate-500 leading-relaxed">
              Include these fields only if customary for your target region (e.g. Germany, UAE, Bangladesh). Leave blank if applying in the US, UK, or Canada.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              <div>
                <label className="block text-slate-600 font-medium mb-1 text-[11px]">Date of Birth</label>
                <input
                  type="text"
                  value={data.dateOfBirth || ''}
                  onChange={(e) => handleChange('dateOfBirth', e.target.value)}
                  placeholder="e.g. 15 March 1995"
                  className="w-full px-2.5 py-1.5 border border-slate-200 rounded text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1 text-[11px]">Nationality / Citizenship</label>
                <input
                  type="text"
                  value={data.nationality || ''}
                  onChange={(e) => handleChange('nationality', e.target.value)}
                  placeholder="e.g. German / British / Canadian"
                  className="w-full px-2.5 py-1.5 border border-slate-200 rounded text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1 text-[11px]">Visa / Work Rights</label>
                <input
                  type="text"
                  value={data.visaStatus || ''}
                  onChange={(e) => handleChange('visaStatus', e.target.value)}
                  placeholder="e.g. PR / Golden Visa / Citizen"
                  className="w-full px-2.5 py-1.5 border border-slate-200 rounded text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1 text-[11px]">Marital Status</label>
                <input
                  type="text"
                  value={data.maritalStatus || ''}
                  onChange={(e) => handleChange('maritalStatus', e.target.value)}
                  placeholder="e.g. Single / Married"
                  className="w-full px-2.5 py-1.5 border border-slate-200 rounded text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1 text-[11px]">Blood Group (optional)</label>
                <input
                  type="text"
                  value={data.bloodGroup || ''}
                  onChange={(e) => handleChange('bloodGroup', e.target.value)}
                  placeholder="e.g. O+ / B+"
                  className="w-full px-2.5 py-1.5 border border-slate-200 rounded text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1 text-[11px]">Religion (optional)</label>
                <input
                  type="text"
                  value={data.religion || ''}
                  onChange={(e) => handleChange('religion', e.target.value)}
                  placeholder="e.g. Islam / Christianity / etc."
                  className="w-full px-2.5 py-1.5 border border-slate-200 rounded text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1 text-[11px]">Father's Name (Biodata)</label>
                <input
                  type="text"
                  value={data.fatherName || ''}
                  onChange={(e) => handleChange('fatherName', e.target.value)}
                  placeholder="Father's Full Name"
                  className="w-full px-2.5 py-1.5 border border-slate-200 rounded text-slate-900"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-medium mb-1 text-[11px]">Mother's Name (Biodata)</label>
                <input
                  type="text"
                  value={data.motherName || ''}
                  onChange={(e) => handleChange('motherName', e.target.value)}
                  placeholder="Mother's Full Name"
                  className="w-full px-2.5 py-1.5 border border-slate-200 rounded text-slate-900"
                />
              </div>

              <div className="sm:col-span-2 md:col-span-1">
                <label className="block text-slate-600 font-medium mb-1 text-[11px]">Permanent Address</label>
                <input
                  type="text"
                  value={data.permanentAddress || ''}
                  onChange={(e) => handleChange('permanentAddress', e.target.value)}
                  placeholder="Permanent Home Address"
                  className="w-full px-2.5 py-1.5 border border-slate-200 rounded text-slate-900"
                />
              </div>

              {/* Japanese JIS Rirekisho Specific Fields */}
              <div className="col-span-full border-t border-slate-200 pt-3 mt-1">
                <span className="font-bold text-[11px] text-blue-700 block mb-2">
                  🇯🇵 Japanese CV / JIS Rirekisho (履歴書) Fields:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-slate-600 font-medium mb-1 text-[11px]">
                      ふりがな (氏名) Furigana Name
                    </label>
                    <input
                      type="text"
                      value={data.furiganaName || ''}
                      onChange={(e) => handleChange('furiganaName', e.target.value)}
                      placeholder="e.g. やまだ たろう / ヤマダ タロウ"
                      className="w-full px-2.5 py-1.5 border border-slate-200 rounded text-slate-900"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 font-medium mb-1 text-[11px]">
                      ふりがな (住所) Furigana Address
                    </label>
                    <input
                      type="text"
                      value={data.furiganaAddress || ''}
                      onChange={(e) => handleChange('furiganaAddress', e.target.value)}
                      placeholder="e.g. とうきょうとしぶやく"
                      className="w-full px-2.5 py-1.5 border border-slate-200 rounded text-slate-900"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 font-medium mb-1 text-[11px]">
                      性別 Gender (男 / 女 / 未記載)
                    </label>
                    <input
                      type="text"
                      value={data.gender || ''}
                      onChange={(e) => handleChange('gender', e.target.value)}
                      placeholder="e.g. 男 / 女"
                      className="w-full px-2.5 py-1.5 border border-slate-200 rounded text-slate-900"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 font-medium mb-1 text-[11px]">
                      通勤時間 Commute Time
                    </label>
                    <input
                      type="text"
                      value={data.commuteTime || ''}
                      onChange={(e) => handleChange('commuteTime', e.target.value)}
                      placeholder="e.g. 約45分"
                      className="w-full px-2.5 py-1.5 border border-slate-200 rounded text-slate-900"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 font-medium mb-1 text-[11px]">
                      扶養家族数 (配偶者を除く)
                    </label>
                    <input
                      type="text"
                      value={data.dependentsCount || ''}
                      onChange={(e) => handleChange('dependentsCount', e.target.value)}
                      placeholder="e.g. 0人"
                      className="w-full px-2.5 py-1.5 border border-slate-200 rounded text-slate-900"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 font-medium mb-1 text-[11px]">
                      配偶者 Spouse (有 / 無)
                    </label>
                    <input
                      type="text"
                      value={data.spouse || ''}
                      onChange={(e) => handleChange('spouse', e.target.value)}
                      placeholder="e.g. 無 / 有"
                      className="w-full px-2.5 py-1.5 border border-slate-200 rounded text-slate-900"
                    />
                  </div>

                  <div className="col-span-full">
                    <label className="block text-slate-600 font-medium mb-1 text-[11px]">
                      志望動機・特技・自己PR (Self PR &amp; Motivation)
                    </label>
                    <textarea
                      rows={3}
                      value={data.selfPr || ''}
                      onChange={(e) => handleChange('selfPr', e.target.value)}
                      placeholder="貴社の技術力と事業展開に共感し..."
                      className="w-full px-2.5 py-1.5 border border-slate-200 rounded text-slate-900"
                    />
                  </div>

                  <div className="col-span-full">
                    <label className="block text-slate-600 font-medium mb-1 text-[11px]">
                      本人希望記入欄 (Personal Requests / Preferences)
                    </label>
                    <input
                      type="text"
                      value={data.personalPreferences || ''}
                      onChange={(e) => handleChange('personalPreferences', e.target.value)}
                      placeholder="貴社の規定に従います。"
                      className="w-full px-2.5 py-1.5 border border-slate-200 rounded text-slate-900"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
