import mongoose, { Document, Schema } from 'mongoose';

export interface ICVData {
  personalInfo: {
    fullName: string;
    jobTitle: string;
    email: string;
    phone: string;
    location: string;
    website?: string;
    linkedin?: string;
    github?: string;
    photo?: string;
    showPhoto?: boolean;
    photoShape?: 'circle' | 'rounded' | 'square';
    dateOfBirth?: string;
    nationality?: string;
    maritalStatus?: string;
    visaStatus?: string;
    religion?: string;
    bloodGroup?: string;
    fatherName?: string;
    motherName?: string;
    permanentAddress?: string;
  };
  summary: string;
  experience: Array<{
    id: string;
    role: string;
    company: string;
    location?: string;
    startDate: string;
    endDate: string;
    current: boolean;
    description: string;
    highlights?: string[];
  }>;
  education: Array<{
    id: string;
    degree: string;
    field: string;
    institution: string;
    location?: string;
    startDate: string;
    endDate: string;
    gpa?: string;
    description?: string;
  }>;
  skills: Array<{
    id: string;
    category: string;
    items: string[];
  }>;
  projects: Array<{
    id: string;
    name: string;
    description: string;
    link?: string;
    technologies: string[];
    highlights?: string[];
  }>;
  certifications: Array<{
    id: string;
    name: string;
    issuer: string;
    issueDate: string;
    expiryDate?: string;
    credentialId?: string;
    url?: string;
  }>;
  languages: Array<{
    id: string;
    language: string;
    proficiency: string;
  }>;
  customSections?: Array<{
    id: string;
    title: string;
    content: string;
  }>;
}

export type TemplateCategoryId =
  | 'ats'
  | 'modern'
  | 'classic'
  | 'minimal'
  | 'executive'
  | 'creative'
  | 'technical'
  | 'academic';

export type CountryId =
  | 'usa'
  | 'canada'
  | 'uk'
  | 'germany'
  | 'eu'
  | 'australia'
  | 'uae'
  | 'bangladesh';

export interface ICV extends Document {
  userId: string;
  title: string;
  countryId: CountryId;
  templateId: TemplateCategoryId;
  themeColor: string;
  fontFamily: 'sans' | 'serif' | 'mono';
  spacing: 'compact' | 'normal' | 'relaxed';
  fontSize: 'compact' | 'normal' | 'large';
  margins: 'compact' | 'normal' | 'relaxed';
  customHeadings: Record<string, string>;
  sectionOrder: string[];
  sectionVisibility: Record<string, boolean>;
  data: ICVData;
  createdAt: Date;
  updatedAt: Date;
}

export const CVSchema: Schema = new Schema(
  {
    userId: {
      type: String,
      required: [true, 'User ID is required'],
      index: true,
    },
    title: {
      type: String,
      required: [true, 'CV title is required'],
      default: 'Untitled CV',
      trim: true,
      maxlength: [120, 'Title cannot exceed 120 characters'],
    },
    countryId: {
      type: String,
      default: 'usa',
    },
    templateId: {
      type: String,
      default: 'modern',
    },
    activeLanguage: {
      type: String,
      default: 'en',
    },
    translations: {
      type: Schema.Types.Mixed,
      default: () => ({}),
    },
    isCustomTemplate: {
      type: Boolean,
      default: false,
    },
    customTemplateHtml: {
      type: String,
      default: '',
    },
    customTemplateCss: {
      type: String,
      default: '',
    },
    themeColor: {
      type: String,
      default: '#2563eb',
    },
    fontFamily: {
      type: String,
      enum: ['sans', 'serif', 'mono'],
      default: 'sans',
    },
    spacing: {
      type: String,
      enum: ['compact', 'normal', 'relaxed'],
      default: 'normal',
    },
    fontSize: {
      type: String,
      enum: ['compact', 'normal', 'large'],
      default: 'normal',
    },
    margins: {
      type: String,
      enum: ['compact', 'normal', 'relaxed'],
      default: 'normal',
    },
    customHeadings: {
      type: Map,
      of: String,
      default: () => ({}),
    },
    sectionOrder: {
      type: [String],
      default: [
        'personalInfo',
        'summary',
        'experience',
        'education',
        'skills',
        'projects',
        'certifications',
        'languages',
        'customSections',
      ],
    },
    sectionVisibility: {
      type: Map,
      of: Boolean,
      default: () => ({
        personalInfo: true,
        summary: true,
        experience: true,
        education: true,
        skills: true,
        projects: true,
        certifications: true,
        languages: true,
        customSections: true,
      }),
    },
    data: {
      type: Schema.Types.Mixed,
      required: true,
      default: () => ({
        personalInfo: {
          fullName: '',
          jobTitle: '',
          email: '',
          phone: '',
          location: '',
          website: '',
          linkedin: '',
          github: '',
        },
        summary: '',
        experience: [],
        education: [],
        skills: [],
        projects: [],
        certifications: [],
        languages: [],
        customSections: [],
      }),
    },
  },
  {
    timestamps: true,
  }
);

export const CVModel = mongoose.models.CV || mongoose.model<ICV>('CV', CVSchema);
